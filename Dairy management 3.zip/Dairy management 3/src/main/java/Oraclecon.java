 import java.sql.*;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author pc
 */
public class Oraclecon { 
       public static void main(String args[])
    {
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","4JN19IS117","vivek");
            if(con != null)
            {
                 System.out.println("connection established");
            }
            
            Statement stmt = con.createStatement();
                if(stmt !=null)
                {
                    System.out.println("Statement created");
                }
               String s1 = "select * from LOGIN";
               ResultSet rs = stmt.executeQuery(s1);
               while(rs.next())
                   System.out.println(rs.getInt(1)+ "  "+rs.getString(2)+ " "+rs.getString(3));
               
               con.close();
            
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
    
}
         
    

